package Arranjos;

public abstract class Arranjo {
    abstract void classificar();
}

public class Violao extends Instrumentos {

    @Override
    public String tocarInstrumento() {
        return "Plim Plim";
    }

    @Override
    public String toString() {
        return "Plim Plim";
    }
}

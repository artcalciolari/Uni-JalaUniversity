public class Trompete extends Instrumentos {

    @Override
    public String tocarInstrumento() {
        return "pááááá";
    }

    @Override
    public String toString() {
        return "pááááá";
    }
}

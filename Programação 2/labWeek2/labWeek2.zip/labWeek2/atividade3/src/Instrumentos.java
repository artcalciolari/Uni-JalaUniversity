abstract class Instrumentos {
    public abstract String tocarInstrumento();
    public abstract String toString();
}

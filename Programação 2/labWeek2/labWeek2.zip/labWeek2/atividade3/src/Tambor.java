public class Tambor extends Instrumentos {

    @Override
    public String tocarInstrumento() {
        return "Pom Pom";
    }

    @Override
    public String toString() {
        return "Pom Pom";
    }
}

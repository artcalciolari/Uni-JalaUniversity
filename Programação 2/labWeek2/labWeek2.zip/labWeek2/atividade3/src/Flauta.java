public class Flauta extends Instrumentos {
    @Override
    public String tocarInstrumento() {
        return "Fiuuuuuuu";
    }

    @Override
    public String toString() {
        return "Fiuuuuuuu";
    }
}

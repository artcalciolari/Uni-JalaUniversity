public class Violino extends Instrumentos {

    @Override
    public String tocarInstrumento() {
        return "siiiiii";
    }

    @Override
    public String toString() {
        return "siiiiii";
    }
}

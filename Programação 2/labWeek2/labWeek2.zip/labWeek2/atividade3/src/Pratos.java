public class Pratos extends Instrumentos {

    @Override
    public String tocarInstrumento() {
        return "Ting Ting";
    }

    @Override
    public String toString() {
        return "Ting Ting";
    }
}

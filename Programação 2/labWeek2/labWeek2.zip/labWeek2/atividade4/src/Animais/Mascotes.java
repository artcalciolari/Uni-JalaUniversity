package Animais;

public abstract class Mascotes {
    abstract String comer();

    abstract String dormir();

    abstract String treinar();

    public abstract String toString();
}

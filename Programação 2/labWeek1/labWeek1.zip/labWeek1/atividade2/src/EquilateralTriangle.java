public class EquilateralTriangle extends  Triangle {
    public EquilateralTriangle(double lado1, double lado2, double lado3) {
        super(lado1, lado2, lado3);
    }
}


public abstract class GeometricForms {
    public abstract double calcularArea();

    public abstract double calcularPerimetro();
}

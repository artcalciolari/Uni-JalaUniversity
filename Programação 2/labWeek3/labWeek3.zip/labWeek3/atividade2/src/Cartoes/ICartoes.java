package Cartoes;

public interface ICartoes {
    void realizarOperacao(int numConta, int numCartao);
}

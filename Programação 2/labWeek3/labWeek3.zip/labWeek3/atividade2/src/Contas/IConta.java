package Contas;

public interface IConta {
    int checarConta();
}

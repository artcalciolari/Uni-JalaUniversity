public interface Professor {
     void teach();
}
